"""digitalsmart URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include,re_path


from django.views.static import serve
from digitalsmart.settings import MEDIA_ROOT
from .views import registered, login_view, logout_view, password_change,upload_user_pic,down_user_pic

urlpatterns = [
    path('registered/', registered),
    path('change/', password_change),
    path('login/', login_view),
    path('logout/', logout_view),
    path('upload/',upload_user_pic ),
    path('down/', down_user_pic),

    path('admin/', admin.site.urls),
    path('attractions/', include("attractions.urls")),
    path('traffic/', include("traffic.urls")),
    path('internet/', include("internet.urls")),

    re_path(r'^media/(?P<path>.*)$',  serve, {"document_root":MEDIA_ROOT}), #图片下载路径

]
