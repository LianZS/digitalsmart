from django.apps import AppConfig


class TrafficConfig(AppConfig):
    name = 'traffic'
