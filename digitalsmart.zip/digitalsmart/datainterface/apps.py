from django.apps import AppConfig


class DatainterfaceConfig(AppConfig):
    name = 'datainterface'
