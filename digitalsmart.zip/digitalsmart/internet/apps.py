from django.apps import AppConfig


class InternetConfig(AppConfig):
    name = 'internet'
