from django.apps import AppConfig


class AttractionsConfig(AppConfig):
    name = 'attractions'
